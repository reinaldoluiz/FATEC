public class Empregado extends PessoaFisica {

	public Empregado(){

	}
	public Empregado(String nome,String sobrenome,String cpf){
		super(nome,sobrenome,cpf);
	}

	@Override
	public String toString(){
		return super.toString();
	}
}
